# Ayudante IA (mod Fabric para Minecraft 26.3)

Asistente de IA dentro de Minecraft: ve tu posición, vida, inventario, bioma y mobs cercanos, y responde en el chat.

**Lee `GUIA_COMPLETA.md`**: explica cómo instalarlo, conseguir una clave gratis (Groq/Gemini), compilarlo con GitHub y compartirlo en Modrinth.

Configs de ejemplo en `ejemplos-config/`. Licencia MIT.
