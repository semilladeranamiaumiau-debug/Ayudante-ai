# Ayudante IA — Guía completa

Mod de Fabric para **Minecraft 26.3**. Es un asistente de IA dentro del juego: ves su respuesta en el chat y él sabe dónde estás, tu vida, tu inventario, el bioma y los mobs cercanos.

---

## 1. Qué trae este paquete
- Código fuente completo del mod (`src/`), listo para compilar.
- `.github/workflows/build.yml`: GitHub compila el mod por ti (sin instalar Java).
- `ejemplos-config/`: configuraciones listas para Groq, Gemini, OpenRouter y Anthropic.
- `MODRINTH.md`: texto listo para pegar en la página del mod en Modrinth.
- `icon.png` del mod, `LICENSE` (MIT) y esta guía.

## 2. Para JUGAR (instalar el mod)
1. Instala **Fabric Loader** para Minecraft **26.3** (instalador de fabricmc.net, Loader 0.19.5 o más).
2. Descarga **Fabric API** para **26.3** (Modrinth) y ponlo en `.minecraft/mods`.
3. Pon `ayudante-ia-1.1.0.jar` (suelto, no dentro de un .zip ni carpeta) en `.minecraft/mods`.
4. Abre el juego con el perfil **fabric-loader-26.3**, entra a un mundo y ciérralo. Se crea `.minecraft/config/ayudante-ia.json`.
5. Saca una clave **gratis** (ver sección 3), pégala en ese archivo y guarda (`Ctrl + S`).
6. En el juego: `/ia recargar` y después `/ia hola`.

### Comandos
| Comando | Qué hace |
|---|---|
| `/ia <mensaje>` | Pregunta a la IA |
| `ia <mensaje>` (en el chat) | Igual que el comando |
| `/ia reiniciar` | Borra la memoria de tu conversación |
| `/ia recargar` | Recarga la configuración |

## 3. Conseguir una clave de IA gratis
Elige UNO. Copia el archivo de `ejemplos-config/` que corresponda, pega tu clave y úsalo como `ayudante-ia.json`.

- **Groq** (console.groq.com → API Keys → Crear clave API). Sin tarjeta. La clave empieza con `gsk_` y **solo se muestra una vez**: cópiala en ese momento.
- **Google Gemini** (aistudio.google.com → Get API key). Sin tarjeta. Es el que más se satura (error 503).
- **OpenRouter** (openrouter.ai). Modelos gratis con `:free` al final del nombre.
- **Anthropic** (console.anthropic.com). De pago (prepago).

Los planes gratis tienen límites diarios y cambian con el tiempo. Si un modelo deja de existir, cambia el valor de `"model"` por otro que muestre la página del servicio.

## 4. Para COMPILAR (generar el .jar)
Sin instalar nada, usando GitHub:
1. Crea una cuenta en github.com y un repositorio nuevo (público).
2. Sube el contenido de la carpeta del proyecto (archivos sueltos, no el .zip). Truco: **GitHub no deja subir arrastrando carpetas que empiezan con punto** (`.github`). Créala escribiendo: *Add file → Create new file* y nombra el archivo `.github/workflows/build.yml`, pegando el contenido de `.github/workflows/build.yml` de este paquete.
3. Entra a **Actions**. Cuando la compilación tenga la palomita verde, abre la ejecución y descarga **ayudante-ia-jar** (Artifacts). Extrae el .zip: adentro está el `.jar`.
4. Para cambiar el código después, sube el archivo modificado a la misma carpeta (reemplaza al viejo) y GitHub recompila solo.

Requisitos si compilas en tu PC: JDK 25 y `gradle wrapper --gradle-version latest`, luego `./gradlew build`. El .jar queda en `build/libs/` (no uses el `-sources`).

## 5. Para COMPARTIR el mod
### Opción A: pasarle el .jar a amigos
Mándales **solo el `.jar`** y los pasos de la sección 2. Cada persona necesita su propia clave gratis. **Nunca mandes tu `ayudante-ia.json`**: tiene tu clave.

### Opción B: publicarlo en Modrinth
1. modrinth.com → inicia sesión → **+** → *Create a project* → tipo **Mod**.
2. Nombre "Ayudante IA", resumen corto. En la descripción pega el contenido de `MODRINTH.md`. Icono: `src/main/resources/assets/ayudante_ia/icon.png`. Licencia: **MIT**.
3. Entorno: servidor *required*, cliente *optional* (ajústalo si ves otro comportamiento).
4. Sube la versión: archivo `ayudante-ia-1.1.0.jar` (no el `-sources`), canal **beta** al principio, loader **Fabric**, juego **26.3**, dependencia **Fabric API** (required).
5. Envía a revisión. Los moderadores lo revisan antes de que sea público (puede tardar días). Cuando lo aprueben aparece en la app de Modrinth.

## 6. Seguridad (importante)
- La clave vive solo en `config/ayudante-ia.json` de cada jugador. El `.jar` NO la contiene.
- Nunca subas tu clave a GitHub, ni la pegues en chats o capturas. Si se filtra: bórrala en el sitio del servicio y crea otra.
- Cada pregunta envía al servicio de IA que elijas tu pregunta y un resumen de tu estado en el juego. Con planes gratis, algunos servicios pueden usar esos datos para mejorar sus productos: no escribas datos personales.
- Mod no oficial, no afiliado a Mojang ni a Microsoft.

## 7. Errores comunes
| Mensaje / síntoma | Qué hacer |
|---|---|
| El mod no carga, no se crea `ayudante-ia.json` | El `.jar` debe estar suelto en `mods`, y usa el perfil Fabric 26.3 |
| "Falta la API key" | Pega la clave en `apiKey`, guarda y `/ia recargar` |
| 401 / "key no válida" | Clave mal copiada o `baseUrl`/`model` de otro servicio |
| 429 / límite | Llegaste al tope gratis: espera o cambia de servicio |
| 503 "high demand" (Gemini) | Reintenta en unos segundos o cambia a Groq |
| Se queda en "pensando..." | Espera hasta 60 s; si no, revisa `logs/latest.log` |
| Error de modelo no encontrado | Cambia `"model"` por otro disponible en ese servicio |

## 8. Ideas para seguir mejorándolo
Reintento automático en errores 503, cambio automático de servicio, acciones seguras (marcar coordenadas, dar efectos), ventana propia de chat, visión con capturas de pantalla.

## 9. Qué sabe la IA de tu mundo (versión actual)
Antes de cada pregunta el mod le manda un informe con:
- **Mundo:** dimensión, día número, dificultad (y si es hardcore), clima.
- **Jugador:** posición, si estás al aire libre/bajo tierra/en agua/lava/ardiendo, luz, vida, hambre, XP, efectos activos, mano, armadura, inventario completo y **dónde moriste por última vez**.
- **Alrededores:** biomas hasta 48 bloques; minerales, cofres, spawners, lava, mesas de crafteo, camas, troncos, etc. a 12 bloques (con las coordenadas del más cercano); mobs hostiles, animales/aldeanos y objetos tirados cerca; otros jugadores.

Límites: no ve estructuras lejanas (aldeas, templos) ni lo que está fuera de ese radio, y la IA está instruida para no inventar lo que no aparece en el informe.

## 10. Radar (aldeas, diamantes y más)
Si en tu pregunta mencionas **aldea, fortaleza, mansión, monumento, tesoro, diamantes, hierro, oro, esmeraldas, redstone, lapis o escombros antiguos** (o la palabra **radar**), el mod hace una búsqueda real en tu mundo y se la da a la IA con coordenadas exactas:
- **Estructuras:** igual que el comando `/locate` (hasta ~1000 bloques). Solo X y Z.
- **Minerales:** escanea los chunks ya cargados (~80 bloques a la redonda) y da los 5 más cercanos con X Y Z.
- Solo funciona en **partidas de un jugador**. En servidores se desactiva a propósito (sería trampa).
- La búsqueda puede congelar el juego un segundo.
